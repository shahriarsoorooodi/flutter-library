import 'package:flutter/material.dart';

class like extends StatefulWidget {
  @override
  _likeState createState() => _likeState();
}

class _likeState extends State<like> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('like'),),
    );
  }
}