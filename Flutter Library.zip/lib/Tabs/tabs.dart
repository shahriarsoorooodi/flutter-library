import 'package:flutter/material.dart';
import 'package:app/Tabs/home.dart';
import 'package:app/Tabs/search.dart';
import 'package:app/Tabs/like.dart';
import 'package:app/Tabs/profile.dart';


class Tabs extends StatefulWidget {
  @override
  _TabsState createState() => _TabsState();
}

class _TabsState extends State<Tabs> with SingleTickerProviderStateMixin {
  TabController _tabController;
  static final _tabpages = <Widget>[
    home(),
    search(),
    like(),
    profile(),
  ];
  static final _tabs = <Tab>[
    Tab(
      icon: Icon(
        Icons.home,
        color: Colors.black,
      ),
    ),
    Tab(
      icon: Icon(
        Icons.search,
        color: Colors.black,
      ),
    ),
    Tab(
      icon: Icon(
        Icons.favorite_border,
        color: Colors.black,
      ),
    ),
    Tab(
      icon: Icon(
        Icons.person,
        color: Colors.black,
      ),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 4,
      vsync: this,
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      color: Colors.white,
      home: DefaultTabController(
        length: 4,
        child: Builder(
          builder: (BuildContext context) {
            return Scaffold(
              body: TabBarView(
                children: _tabpages,
                controller: _tabController,
              ),
              bottomNavigationBar: Material(
                color: Colors.white,
                child: TabBar(
                  tabs: _tabs,
                  controller: _tabController,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
